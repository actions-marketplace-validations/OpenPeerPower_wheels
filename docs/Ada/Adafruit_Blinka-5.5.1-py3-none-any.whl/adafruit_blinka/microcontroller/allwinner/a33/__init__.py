"""Definition for the AllWinner A33 chip"""
